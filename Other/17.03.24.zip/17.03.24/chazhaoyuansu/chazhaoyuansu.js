/**
 * Created by goyo- on 2017/3/24.
 */
    function jisuan(shuru) {
        var a=shuru.value;
        var b=a.length;
        document.getElementById("show1").innerHTML=b;
    }