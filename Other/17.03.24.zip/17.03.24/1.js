document.write("erwerewrwe")
document.getElementById("show1").innerHTML=date();